"""
run.py
======
Run Box's Apprentice on your 200 distributions.

Usage:
    python run.py --data path/to/your_data.pkl --rounds 3 --model gpt-4o
"""

import os
import sys
import pickle
import argparse
import numpy as np

# ── run.py lives in agents/ so simple_box_loop_adapter.py is right next to it
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from simple_box_loop_adapter import run_all_arrays


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data",   required=True,
                   help="Path to your .pkl file (list of dicts with a 'data' key)")
    p.add_argument("--output", default="results.pkl",
                   help="Where to save results (default: results.pkl)")
    p.add_argument("--rounds", type=int, default=3,
                   help="Refinement rounds per array (default: 3)")
    p.add_argument("--model",  default="gpt-4o",
                   help="LLM to use: gpt-4o or a claude model string")
    p.add_argument("--no-resume", action="store_true",
                   help="Start from scratch even if output file already exists")
    p.add_argument(
        "--task",
        choices=["box_loop", "box_loop_ts"],
        default="box_loop",
        help="Which task to run: original (box_loop) or time-series GP (box_loop_ts)"
    )
    return p.parse_args()


def load_data(path: str) -> dict:
    """Load the pkl file and return {array_id: 1-D numpy array}."""
    with open(path, "rb") as f:
        raw = pickle.load(f)
        print("RUNNING ON A SAMPLE OF 1")
        raw = raw[:1]

    if not isinstance(raw, list):
        raise ValueError(f"Expected a list of dicts, got {type(raw)}")
    if "data" not in raw[0]:
        raise ValueError(
            f"Each dict must have a 'data' key. "
            f"Keys found: {list(raw[0].keys())}"
        )

    arrays_dict = {}
    for i, item in enumerate(raw): 
        arr = np.asarray(item["data"], dtype=float)
        if arr.ndim != 1:
            raise ValueError(
                f"Item {i}: 'data' must be 1-D, got shape {arr.shape}. "
                "Flatten it before saving, or update this loader."
            )
        arrays_dict[i] = arr

    print(f"Loaded {len(arrays_dict)} arrays from {path}")
    for i in range(min(3, len(arrays_dict))):
        a = arrays_dict[i]
        print(f"  [{i}] n={len(a)}  mean={a.mean():.3f}  std={a.std():.3f}")
    if len(arrays_dict) > 3:
        print(f"  ... and {len(arrays_dict) - 3} more")

    return arrays_dict

def load_data_ts(path: str) -> dict:
    """
    Load a list-of-dicts time series dataset.
    Each element has keys: series_id, unique_id, category, name,
                           anomaly_info, source_path, data (pd.Series).
    Returns {series_id: series_dict} — same shape as arrays_dict for box_loop.
    """
    with open(path, "rb") as f:
        series_list = pickle.load(f)
        # print("WARNING: RUNNING ON MINI")
        # series_list = series_list[:2]  # TEMP: only use 10 series for now

    return {item["series_id"]: item for item in series_list}


def main():
    args = parse_args()
    # ── load data ──────────────────────────────────────────────────────────
    if args.task == "box_loop_ts":
        arrays_dict = load_data_ts(args.data)
    else:
        arrays_dict = load_data(args.data)

    # ── run ───────────────────────────────────────────────────────────────
    results = run_all_arrays(
        arrays_dict=arrays_dict,
        model_name=args.model,
        num_rounds=args.rounds,
        save_path=args.output,
        resume=not args.no_resume,
        task=args.task,
    )

    # ── summary ───────────────────────────────────────────────────────────
    n_ok = sum(r["success"] for r in results)
    print(f"\n{'='*50}")
    print(f"Done.  {n_ok}/{len(results)} arrays succeeded.")
    print(f"Results saved to: {args.output}")
    print(f"{'='*50}\n")

    print("LOO scores (best first):")
    for r in sorted(results, key=lambda x: x["best_loo"], reverse=True):
        ok = "✓" if r["success"] else "✗"
        print(f"  [{ok}] array {r['array_id']:3d}  LOO={r['best_loo']:.2f}")


if __name__ == "__main__":
    main()