import re
import anthropic
import openai
from openai import OpenAI
import os
from anthropic import AnthropicBedrock

class LMExperimenter:
    def __init__(self, model_name, temperature=1.0, max_tokens=3000):
        self.model_name   = model_name
        self.temperature  = temperature
        self.max_tokens   = max_tokens
        self.messages     = []   # conversation history passed to responses.create
        self.all_messages = []   # full log (debug only)
        self.system       = None

        if "gpt" in model_name:
            self.llm = openai.AzureOpenAI(
                api_key=os.environ["azure_api_key"],
                api_version=os.environ["azure_api_version"],
                azure_endpoint=os.environ["azure_endpoint"],
            )
        elif "claude" in model_name:
            self._bedrock_model_id = "us.anthropic.claude-sonnet-4-6"
            self.llm = AnthropicBedrock(
                aws_access_key=os.environ["aws_access_key"],
                aws_secret_key=os.environ["aws_secret_key"],
                aws_region=os.environ["aws_region"],
            )
        
        elif "Qwen" in model_name or "together" in model_name:
            self.llm = OpenAI(
                api_key=os.environ["TOGETHER_API_KEY"],
                base_url="https://api.together.xyz/v1",
                )
            

    def set_system_message(self, message):
        self.all_messages.append(f"role:system, message:{message}")
        if "gpt" in self.model_name:
            self.messages.append({
                "role": "system",
                "content": [{"type": "input_text", "text": message}]
            })
        elif "claude" in self.model_name:
            self.system = message

    def add_message(self, message, role="user"):
        self.all_messages.append(f"role:{role}, message:{message}")
        if "gpt" in self.model_name:
            content_type = "output_text" if role == "assistant" else "input_text"
            self.messages.append({
                "role": role,
                "content": [{"type": content_type, "text": message}]
            })
        elif "claude" in self.model_name or "Qwen" in self.model_name:
            self.messages.append({
                "role": role,
                "content": [{"type": "text", "text": message}]
            })
        

    def prompt_llm(self, request_prompt):
        self.add_message(request_prompt, role="user")
        if "gpt" in self.model_name:
            response = self.llm.responses.create(
                model=self.model_name,
                input=self.messages,
                max_output_tokens=self.max_tokens,
                #temperature=self.temperature,
                reasoning={"effort": "low"},
                #top_p=1.0,
            )
            full_response = response.output_text
        elif "claude" in self.model_name:
            response = self.llm.messages.create(
                model=self.model_name,
                system=self.system,
                messages=self.messages,
                max_tokens=self.max_tokens,
                temperature=1.0,  # must be 1.0 when extended thinking is enabled
                thinking={"type": "enabled", "budget_tokens": 1024},  # minimum reasoning budget
            )
            # thinking blocks come before text blocks, so find the text block explicitly
            full_response = next(b.text for b in response.content if b.type == "text")
        elif "Qwen" in self.model_name:
            full_response = self.llm.chat.completions.create(
                model=self.model_name,
                messages=self.messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
            ).choices[0].message.content
        else:
            raise ValueError(f"Model '{self.model_name}' not recognised. Add it to agent.py.")
        self.add_message(full_response, role="assistant")
        return full_response

    def parse_response(self, response, is_observation):
        pattern = r'<observe>(.*?)</observe>' if is_observation else r'<answer>(.*?)</answer>'
        match = re.search(pattern, response, re.DOTALL)
        return match.group(1).strip() if match else None

    def prompt_llm_and_parse(self, request_prompt, is_observation, max_tries=4):
        used_retries = 0
        for i in range(max_tries):
            full_response = self.prompt_llm(request_prompt)
            response = self.parse_response(full_response, is_observation)
            if response is not None:
                if len(re.findall(r'[0-9]+', response)) == 0:
                    response = None
            if response is None or "done" in response:
                if is_observation:
                    request_prompt = "Please stick to the specified format and respond using <observe> tags. Continue making observations even if you think you have an accurate estimate. Your previous response was not valid."
                else:
                    request_prompt = "Please stick to the specified format and respond using <answer> tags. Make assumptions and provide your best guess. Your previous response was not valid."
                used_retries += 1
            else:
                break
        if used_retries == max_tries:
            raise ValueError("Failed to get a valid response after max retries.")
        return response, used_retries

    def generate_predictions(self, request_prompt):
        request_prompt += "\nAnswer in the following format:\n<answer>your answer</answer>."
        prediction, used_retries = self.prompt_llm_and_parse(request_prompt, False)
        self.messages = self.messages[:-2 * (used_retries + 1)]
        return prediction

    def generate_actions(self, experiment_results=None):
        if experiment_results is None:
            follow_up_prompt = (
                "Think about where to observe next. Articulate your strategy for choosing "
                "measurements in <thought>.\nProvide a new measurement point in the format:\n"
                "<thought>your thought</thought>\n<observe>your observation</observe>\n"
                "Make an observation now."
            )
        else:
            follow_up_prompt = (
                f"Result: {experiment_results}\nThink about where to observe next. "
                "Articulate your strategy for choosing measurements in <thought>.\n"
                "Provide a new measurement point in the format:\n"
                "<thought>your thought</thought>\n"
                "<observe>your observation (remember the type of inputs accepted)</observe>"
            )
        observe, used_retries = self.prompt_llm_and_parse(follow_up_prompt, True)
        return observe

    def print_log(self):
        for entry in self.all_messages:
            print(entry)
            print("------")