#!/bin/bash

# ── API Keys ────────────────────────────────────────────────────────────────
export AZURE_API_KEY=""
export AZURE_OPENAI_API_KEY="" 
export AZURE_API_BASE=""
export AZURE_API_VERSION=""

export TOGETHER_API_KEY=""

export aws_access_key=""
export aws_secret_key=""
export aws_region=""

# ── Args ─────────────────────────────────────────────────────────────────────
DATA="dataset_ts_easy_50.pkl"
OUTPUT="results_claude_easy_ts.pkl"
#"gpt-5.4-mini"  #"Qwen/Qwen3.5-397B-A17B"  # "us.anthropic.claude-sonnet-4-6"
MODEL="us.anthropic.claude-sonnet-4-6"
ROUNDS=1

# ── Run ──────────────────────────────────────────────────────────────────────
python run.py \
    --data    "$DATA"   \
    --output  "$OUTPUT" \
    --model   "$MODEL"  \
    --rounds  "$ROUNDS" \
    --task    "box_loop_ts"
